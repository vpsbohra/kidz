import React from 'react';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleChevronDown } from '@fortawesome/free-solid-svg-icons';

import img1 from '../images/Group(1).png';
import img2 from '../images/Group(4).png';
import img3 from '../images/Group(2).png';
import img4 from '../images/Group(3).png';
import Accordion from './Accordion';
export default function FrequentlyAskedQuestions() {
    
    return(
        <section className="section-FrequentlyAsked">
            <div className="container">
                <div className="row FrequentlyAsked_row">
                <div className="FrequentlyAsked_imgsec">
                   <img src={img1} className='frequentlyAskedimg frequentlyAsked_img1' alt="group-1" />
                   <img src={img2} className='frequentlyAskedimg frequentlyAsked_img2' alt="group-2" />
                   <img src={img3} className='frequentlyAskedimg frequentlyAsked_img3' alt="group-3" />
                   <img src={img4} className='frequentlyAskedimg frequentlyAsked_img4' alt="group-4" />
            </div>
                <div className="FrequentlyAsked_content">
                    <h2>Frequently Asked Questions</h2>
                    <ul>
                        <li> <Accordion title="Lorem ipsum dolor sit amet consectetur quis pulvinar enim?" content="Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?" /></li>
                        <li> <Accordion title="Lorem ipsum dolor sit amet consectetur quis pulvinar enim?" content="Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?" /></li>
                        <li> <Accordion title="Lorem ipsum dolor sit amet consectetur quis pulvinar enim?" content="Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?" /></li>
                        <li> <Accordion title="Lorem ipsum dolor sit amet consectetur quis pulvinar enim?" content="Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?" /></li>
                        <li> <Accordion title="Lorem ipsum dolor sit amet consectetur quis pulvinar enim?" content="Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?Lorem ipsum dolor sit amet consectetur quis pulvinar enim?" /></li>
                    </ul>
                </div>
                </div>
            </div>
        </section>
    )
}