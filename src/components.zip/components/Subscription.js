import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useState, useEffect } from "react"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck } from '@fortawesome/free-solid-svg-icons';
import AuthUser from './AuthUser';

export default function Suscription() {
    const location = useLocation();
    const navigate = useNavigate();
    const [selectedPlan, setSelectedPlan] = useState(null);
    const [selectedBilling, setSelectedBilling] = useState('monthly');
    const {http,setToken} = AuthUser();
    const {token} = AuthUser();
    const [errors, setErrors] = useState({});

    const selectedBillingDefault = 'monthly';
    const isSelectButtonDisabled = selectedPlan === null;
    const [currentPlan, setCurrentPlan] = useState('');
    const [user, setUser] = useState('');

    const handlePlanClick = (plan) => {
        setSelectedPlan(plan);
    };
    const handleBillingSelect = (billing) => {
        setSelectedBilling(billing);
    };
    
    const renderBilledButtons = () => {
        if (selectedPlan === 'classic') {
          return (
            <div className="billed-btns">
              <label>
                <input type="radio" name="billing" value="monthly" checked={selectedBilling === 'monthly'} selected="selected" onChange={() => handleBillingSelect('monthly')} />
                Billed Monthly
              </label>
            </div>
          );
        }
    
        if (selectedPlan === 'fidelity') {
          return (
            <div className="billed-btns">
              <label>
                <input type="radio" name="billing" value="monthly" checked={selectedBilling === 'monthly'} selected="selected"  onChange={() => handleBillingSelect('monthly')} />
                Billed Monthly
              </label>
              <label>
                <input type="radio" name="billing" value="quarterly" onChange={() => handleBillingSelect('quarterly')}/>
                Billed Quarterly
              </label>
              <label>
                <input type="radio" name="billing" value="yearly" onChange={() => handleBillingSelect('yearly')} />
                Billed Annualy
              </label>
            </div>
          );
        }
    
        return null;
      };

      const renderFidelityPrice = () => {
        if (selectedPlan === 'fidelity') {
            if (selectedBilling === 'monthly') {
                return '$8/mo';
            } else if (selectedBilling === 'quarterly') {
                return '$24/qtly';
            } else if (selectedBilling === 'yearly') {
                return '$96/yr';
            }
        }
        return '$8/mo';
    };
    const renderClassicPrice = () => {
          if (selectedPlan === 'classic') {
            return '$5/mo';
          }
      };
   


        useEffect(() => {
            const userInformation = sessionStorage.getItem('user');
        
            if (userInformation) {
                const user = JSON.parse(userInformation);
                const { plan } = user;
                setCurrentPlan(plan);
                setUser(user);

            } else {
              console.log('User information not found in sessionStorage.');
            }
          }, []);
          
    const submitForm = () => {
        fetch(`http://195.110.34.253/api/upgrade-plan?user_id=${user.id}`, {
            method: 'PUT',
            headers: {
            'Content-Type': 'application/json',
            "Authorization" : `Bearer ${token}` 
            },
            body: JSON.stringify({ billing: selectedBilling, plan: selectedPlan }),
        })
        .then(response => response.json())
        .then(data => {
            user.plan = selectedPlan;
            user.billing = selectedBilling;
            sessionStorage.setItem('user', JSON.stringify(user));
            navigate('/parent-dashboard');
          })
        .catch(error => {
            console.error('Error updating billing information:', error);
        });
        };

    return(
        <section className="section-plans">
            <div className="container">
                <div className="row plans_header">
                    <h2>Select your plan</h2>
                    {renderBilledButtons()}
                    </div>
                    <div className="row plans_row_sr">
                        <div className={`col plans_item_sr ${selectedPlan === 'free' ? 'selected' : ''}`} >
                            <h2>Free</h2>
                            <p>$0</p>
                            <ul>
                                <li><FontAwesomeIcon icon={faCheck} /> Access to all stories and activities</li>
                                <li><FontAwesomeIcon icon={faCheck} /> Limited interaction sharing via WhatsApp</li>
                                <li><FontAwesomeIcon icon={faCheck} /> Up to 2 child profiles</li>
                                <li><FontAwesomeIcon icon={faCheck} /> Available on all devices</li>
                            </ul>
                            <button type="button" onClick={() => handlePlanClick('free')}>
                                Select
                            </button>
                        </div>
                        <div className={`col plans_item_sr ${selectedPlan === 'classic' ? 'selected' : ''}`} >
                            <h2>Classic</h2>
                            <p className="classic-price" >$5/mo</p>
                            <ul>
                                <li><FontAwesomeIcon icon={faCheck} /> Everything from Free plan + </li>
                                <li><FontAwesomeIcon icon={faCheck} /> Parent dashboard</li>
                                <li><FontAwesomeIcon icon={faCheck} /> Unlimited children profiles</li>
                                <li><FontAwesomeIcon icon={faCheck} /> Full access to sharing of interactions</li>
                                <li><FontAwesomeIcon icon={faCheck} /> Recorded interactions (audios, child activities, etc) for 1 month</li>

                            </ul>
                            <button type="button" onClick={() => handlePlanClick('classic')}>
                                Select
                            </button>
                        </div>
                        <div  className={`col plans_item_sr ${selectedPlan === 'fidelity' ? 'selected' : ''}`} >
                            <h2>Fidelity</h2>
                            <p className="fiedly-price">{renderFidelityPrice()}</p>
                            <ul>
                                <li><FontAwesomeIcon icon={faCheck} /> Everything from Classic plan +</li>
                                <li><FontAwesomeIcon icon={faCheck} /> Recorded interactions (audios, child activities, etc) for 24 months</li>
                                <li><FontAwesomeIcon icon={faCheck} /> Interaction history for 24 months</li>
                            </ul>
                            <button type="button" onClick={() => handlePlanClick('fidelity')}>
                                Select
                            </button>
                        </div>
                </div>
                <div className="prev-next-page">
                    <Link className='button_cntr_sub button_cntrlogin' to="/login">
                    <button type="button">Back</button>
                    </Link>
                   
                    {user ? (
                    <Link onClick={submitForm} className='button_cntr_sub button_cntrcontinue' >
                        <button type="button">
                        Update Billing
                        </button>
                    </Link>
                    ) : (
                        <Link
                        className='button_cntr_sub button_cntrcontinue'
                        to={`/sign-up?plan=${selectedPlan}${
                          selectedPlan === 'free' ? '&billing=null' : selectedBilling
                            ? `&billing=${selectedBilling}`
                            : ''
                        }${selectedPlan === 'fidelity' ? `&price=${renderFidelityPrice()}` : ''}${
                          selectedPlan === 'classic' ? `&price=${renderClassicPrice()}` : ''
                        }`}
                      >
                        <button type="button">
                          Continue
                        </button>
                      </Link>
                    )}

                </div>
            </div>
        </section>
    )
}