import { useState } from "react"
import AuthUser from './AuthUser';
import { Link } from 'react-router-dom';
import GoogleImage from '../images/google_icon.png';
import FBImage from '../images/fb_icon.png';
import AppleImage from '../images/apple_icon.png';
import { GoogleOAuthProvider } from '@react-oauth/google';
import GoogleAuthLogin from './GoogleAuthLogin';
export default function Login() {
    const {http,setToken} = AuthUser();
    const [email,setEmail] = useState();
    const [password,setPassword] = useState();
    const [errors, setErrors] = useState([]);

    const submitForm = () =>{
        
        http.post('/login',{email:email,password:password}).then((res)=>{
            setToken(res.data.user,res.data.access_token);
        }).catch((error) => {
            if (error.response && error.response.data && error.response.data.errors) {
                setErrors(error.response.data.errors);
            }
        });
    }
    const [errorMessage, setErrorMessage] = useState('');
    const handleError = (message) => {
        setErrorMessage(message);
      };
    return(
        <div className="login_page_sr">
            <div className="container">
                <div className="row justify-content-center pt-5">
                    <div className="col-sm-6">
                        <div className="card login_sr_cnt p-4">
                            <h1 className="text-center mb-3">Login </h1>
                            <div className="form-group">
                                <label>Email address:</label>
                                <input type="email" className="form-control" placeholder="Enter email"
                                    onChange={e=>setEmail(e.target.value)}
                                id="email" />
                                {errors && errors.email && (
                                    <span className="text-danger">{errors.email[0]}</span>
                                )}
                            </div>
                            <div className="form-group mt-3">
                                <label>Password:</label>
                                <input type="password" className="form-control" placeholder="Enter password"
                                    onChange={e => setPassword(e.target.value)}
                                id="pwd" />
                                {errors && errors.password && (
                                    <span className="text-danger">{errors.password[0]}</span>
                                )}
                            </div>
                            <div className="form-group Password_group mt-3">
                                <div className="show-pass"> <input type="checkbox" className="ch" />Show Password</div>
                            <   div className="forget-pass"><Link className="nav-link" to="/">Forget Password?</Link></div>
                            </div>
                            <div className="form-group login_btnsr mt-3">
                                <button type="button" onClick={submitForm} className="btn btn-primary mt-4">Login</button>
                            </div>
                            <div className="form-group mt-3 or_text">
                               <span>OR</span>
                            </div>
                            <div className="form-group login_with_btncnrl mt-3">
                                <GoogleOAuthProvider clientId="211892139032-031hag3n8u2u3m1s39nhpjjrauakc32k.apps.googleusercontent.com">
                                    <GoogleAuthLogin onError={handleError}/>
                                </GoogleOAuthProvider>
                                <button type="button" className="login-with-facebook-btn" ><img src={FBImage} alt="meet-character-1" /> Sign in with Facebook</button>
                                <button type="button" className="login-with-apple-btn" ><img src={AppleImage} alt="meet-character-1" /> Sign in with Apple</button>
                            </div>
                            <div className="form-group Signup_btn mt-3">
                                <p>Don't have an account?</p>
                                <Link className="btn btn-primary mt-4" to="/subscription">Signup</Link>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}