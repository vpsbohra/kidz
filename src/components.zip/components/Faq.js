import React from 'react';
import Footer from './Footer';
import search_keywordIMG from '../images/search_keyword.png';
export default function Faq() {
    
    return (
        <>
        <div className="main-container faq_page">
            <div className="container">
                <div className="faq_page_inner">
                     <div className="faq_page_head">
                        <h1>How Can We Help</h1>
                        <div className="faq_page_head_form"> 
                            <img src={search_keywordIMG} alt="logo" />
                            <input className="form-control mr-sm-2" type="search" placeholder="Search keyword" aria-label="Search" />   
                        </div>
                    </div>
                    <div className="faq_row_item">
	<div className="left_faq faq_multiitem">
		<div className="col faq_col_item">
			<h2>About KidzConnect</h2>
			<div className="content">
				<p>What is KidzConnect</p>
				<p>Which characters are on KidzConnect</p>
				<p>Is the KidzConnect environment safe and secure for children</p>
			</div>
		</div>
		 <div className="col faq_col_item">
			<h2>Usage and Requirements</h2>
			<div className="content">
				<p>How old do you have to be to use KidzConnect</p>
				<p>Is KidzConnect available on mobile</p>
				<p>Is KidzConnect available in multiple languages</p>
			</div>
		</div>
		<div className="col faq_col_item">
			<h2>Account and Profile Management</h2>
			<div className="content">
				<p>How do I create an account on KidzConnect</p>
				<p>How can I register multiple children with a single email address</p>
				<p>How can I modify my profile information</p>
				<p>How can I recover my password if I forget it</p>
				<p>How can I cancel my KidzConnect subscription</p>
			</div>
		</div>
		<div className="col faq_col_item">
			<h2>Subscriptions and Pricing</h2>
			<div className="content">
				<p>How do the different subscriptions work</p>
				<p>What payment methods are accepted for subscriptions</p>
				<p>Are there any discounts</p>
			</div>
		</div>
	</div>


	<div className="right_faq_item faq_multiitem">
		<div className="col faq_col_item">
			<h2>Content and Features</h2>
			<div className="content">
				<p>Can children listen to, read, or interact with KidzConnect content outside the website</p>
				<p>How does the MasterKidz game in KidzConnect work</p>
				<p>How do kids earn more points in KidzConnect</p>
			</div>
		</div>
		<div className="col faq_col_item">
			<h2>Parental Involvment and Monitoring</h2>
			<div className="content">
				<p>Does my child have the ability to ask questions to their parents</p>
				<p>How can I interact with my child's answers to questions</p>
				<p>Can my child repeat a theme more than once</p>
				<p>How can I share my child's interaction with other family members</p>
				<p>How can I track my child's progress in the application</p>
			</div>
		</div>
		<div className="col faq_col_item">
			<h2>Policies and Support</h2>
			<div className="content">
				<p>What are KidzConnect's rules and policies regarding respect and safety</p>
				<p>How can I contact customer support</p>
				<p>How can I report a problem or bug on the website</p>
				<p>How can I contact the development team for questions, feedback, or technical issues</p>
			</div>
		</div>
	</div>
</div>
                </div>
            </div>
        </div>
        <Footer />
        </>
      );
}