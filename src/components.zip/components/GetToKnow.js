import React from 'react'

import Image1 from '../images/know-children.png';
import Image2 from '../images/Parents&Kids_img.png';
export default function GetToKnow() {
    return(
        <section className="get-to-know">
            <div className="container">
                <div className="row">
                    <div className="left-section col-6">
                        <h1>Get to know your child</h1>
                        <p>Get a deeper understanding of your child's world and gain valuable insights into their development, interests, and strengths, empowering you to support and nurture their individual growth. KidzConnect allows you to connect on a whole new level, fostering a stronger relationship built on knowledge, understanding, and shared experiences.</p>
                        <button className='content_btn' type='button'>LET ME GET STARTED</button>
                    </div>
                    <div className="right-section col-6">
                        <img src={Image1} alt="Description of the" />    
                    </div>
                </div>
                <div className="row section_one_rowtwo">
                    <div className="left-section col-6">
                        <img src={Image2} alt="Description of the" />    
                    </div>
                    <div className="right-section col-6">
                        <h1>Connecting Parents and Kids</h1>
                        <p><span>We understand the challenges of being an involved parent in today's digital age.</span></p>

                        <p>As a parent you want to be invested in your kids day to day yet find yourself not really knowing what’s going on in their lives. Similarly, from your child’s perspective, they may want come to you for certain topics but not know what to say or  simply it never being the “right moment”.</p>

                        <p>Kidzconnects bridges the gap between parents and kids with KidzConnect, providing a safe space for children to explore daily topics while fostering a stronger parent-child bond, making every moment the right moment to connect.</p>
                        <button className='content_btn' type='button'>Learn More</button>
                    </div>
                </div>
            </div>
        </section>
    )
}
