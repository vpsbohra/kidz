import React from 'react';
import KidzeConnectImg from '../images/Family-Photo.png';
import KidzeConnectImg1 from '../images/Kidzconnect_eff1.png';
import KidzeConnectImg2 from '../images/Kidzconnect_eff2.png';
import KidzeConnectImg3 from '../images/Kidzconnect_eff3.png';
import KidzeConnectImg4 from '../images/Kidzconnect_eff4.png';
import KidzeConnectImg5 from '../images/Kidzconnect_eff5.png';
import KidzeConnectImg6 from '../images/Kidzconnect_eff6.png';


export default function KidzeConnectBring() {
    return(
        <section className="section-kidzeconnect-bring">
            <div className="container">
                <div className="row">
                    <div className="kidzeconnect_bring_header">
                        <h2>How Kidzconnect brings it all together</h2>
                        <p>Capture cherished moments with a sound gallery that preserves memories just like a photo album</p>
                   </div>
                   </div>
                   <div className="row kidzeconnect_bring_content">
                   <div className="bringleft col-6">
                        <img src={KidzeConnectImg} alt="testiimonial-right" />
                   </div>
                   <div className="bringright col-6"> 
                <ul>
                    <li><img src={KidzeConnectImg1} alt="KidzeConnectImg1" />Create lasting memories through voice recordings of interactions</li>
                    <li><img src={KidzeConnectImg2} alt="KidzeConnectImg2" />Share content and memories with other family members</li>
                    <li><img src={KidzeConnectImg3} alt="KidzeConnectImg3" />Facilitate tracking your child's progress with the parental space</li>
                    <li><img src={KidzeConnectImg4} alt="KidzeConnectImg4" />Contributes to a shared and enriching learning experience</li>
                    <li><img src={KidzeConnectImg5} alt="KidzeConnectImg5" />Active participation in your child's education</li>
                    <li><img src={KidzeConnectImg6} alt="KidzeConnectImg6" />Strengthen family bonds through parent-child interaction</li>
                </ul>
                   </div>
                </div>
            </div>
        </section>
    )
}