import React, { useEffect, useState } from 'react';
import Pusher from 'pusher-js';
import AuthUser from '../AuthUser';
import KidsNav from '../../navbar/kidzNav';
import { Link } from 'react-router-dom';
import sendImage from '../../images/sendVector.png';
import PaperClipImage from '../../images/paper-clip.png';
import EmojiImage from '../../images/Emoji_icon.png';
import SendAudioImage from '../../images/Send-audio-message.png';

const ChildChat = () => {
  const { http } = AuthUser();
  const { user } = AuthUser();
  const [messages, setMessages] = useState([]);
  const [username, setUsername] = useState('');
  const [userdetail, setUserdetail] = useState({});
  const [message, setMessage] = useState('');
  const userInfo = sessionStorage.getItem('user');
  const userInfoDetail = JSON.parse(userInfo);
  const spouses = userInfoDetail.spouse;
  const [spouse, setSpouses] = useState(spouses);

  const dataId = userInfoDetail.id;
  const childId = sessionStorage.getItem('childId');
  useEffect(() => {
    Pusher.logToConsole = true;

    const pusher = new Pusher('8bc60721fd702db2ed68', {
      cluster: 'ap2',  
      encrypted: true,
    });
    const channel = pusher.subscribe('chat');

    channel.bind('message', function (data) {
      setMessages((prevMessages) => [...prevMessages, data]);
      
    });

    return () => {
      pusher.unsubscribe('chat');
    };
    
  }, []); 

  useEffect(() => {
    fetchUserDetail();
    fetchMessages();  
  }, [spouse]);
  
  const fetchMessages = async () => {
    // console.log(spouse);
    const senderId = childId;
    const receiverId = dataId;
    try {
      const response = await http.get(`/messages/${senderId}/${receiverId}/${spouse}`);
      const messagesFromApi = response.data;
      setMessages(messagesFromApi);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const fetchUserDetail = () => { 
    setUserdetail(user);
    setUsername(user.name.split(' ')[0]);
  };

  const submit = () => {
    const senderId = childId;
    const receiverId = userdetail.id;

    http
      .post('/messages', { username, message, senderId, receiverId, spouse })
      .then((response) => {
        console.log('Message saved:', response.data);
      })
      .catch((error) => {
        console.error('Error saving message:', error);
      });

    setMessage(''); 
  };

  useEffect(() => { 
    // Save messages to local storage when messages state changes
    localStorage.setItem('messages', JSON.stringify(messages));
  }, [messages]);

  const handleChildClick = (spouse) => {
    setSpouses(spouse);
  };
  return (
    <div className="kidzdashboard">
        <div className="container-fluid display-table">
          <KidsNav />
          <div className="main-content">
          <div className="page_ttl">
             <h1>Messages</h1>
            </div>
            
    <div className="chat_section_sr childchatsection_sr">
    <div className="childchatsection_inner_sr">
        
      <div className="chat_section_sr_left child_chat_sr_left">
        <div onClick={() => handleChildClick('Pierre')} className="d-flex w-100 align-items-center justify-content-between childchat_messages">
            <strong className="mb-1">D</strong>
            <span>June 7th, 4:30 pm</span>
        </div>
        <div onClick={() => handleChildClick('Mom')} className="d-flex w-100 align-items-center justify-content-between childchat_messages">
            <strong className="mb-1">M</strong>
            <span>June 7th, 4:30 pm</span>
        </div>
        <div onClick={() => handleChildClick('Auntie')} className="d-flex w-100 align-items-center justify-content-between childchat_messages">
            <strong className="mb-1">A</strong>
            <span>June 7th, 4:30 pm</span>
        </div>
      </div>
      <div className="child_chat_sr_right">
      <div className="chat_section_sr_right">
        <div className="d-flex flex-column align-items-stretch flex-shrink-0 bg-white">
          <div className="user_name_chat d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none border-bottom">
            <input
              className="fs-5 fw-semibold"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div className="list-group user_list_sr_outer list-group-flush border-bottom scrollarea">
            {messages.map((message, index) => (
              <div 
                key={index}
                className="list-group-item user_list_sr list-group-item-action py-3 lh-tight"
              >
                <div className="user_list_groupsr">
                  <div className="col-10 mb-1 small user_message_sr">{message.message}</div>
                  <div className="d-flex w-100 align-items-center justify-content-between user_name_label">
                    <strong className="mb-1">P</strong>
                  </div>
                </div>
                <div className="user_time_sr">
                  <span>3:43 pm</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
        <div className="chat_form_input">
        <input
          className="form-control"
          placeholder="Write a message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <div className="chat_form_input_btncnrl">
          <div className="chat_form_input_btncnrlLeft">
            <Link className="confirm" to="#"><img src={PaperClipImage} alt="protected" /></Link>
            <Link className="confirm" to="#"><img src={EmojiImage} alt="protected" /></Link>
          </div>
          <div className="chat_form_input_btncnrlRight">
            <button onClick={submit}>
              <img src={sendImage} alt="protected" />
            </button>
            <button onClick={submit}>
              <img src={SendAudioImage} alt="protected" />
            </button>
          </div>
        </div>
      </div>
      </div>
      </div>

    </div>
        </div>
      </div>
    </div>
  );
};

export default ChildChat;
