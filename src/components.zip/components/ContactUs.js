import React from 'react';
import axios from 'axios';
import Footer from './Footer';

const ContactUs = () => {
  const [formStatus, setFormStatus] = React.useState('SEND MESSAGE');

  const onSubmit = (e) => {
    e.preventDefault();
    setFormStatus('Submitting...');
    
    const { name, email, message } = e.target.elements;
    const formData = {
      name: name.value,
      email: email.value,
      message: message.value,
    };
    
    axios.post('http://195.110.34.253/api/send-email', formData)
      .then((response) => {
        console.log(response.data);
        setFormStatus('Email Sent!');
      })
      .catch((error) => {
        console.error(error);
        setFormStatus('Failed to send');
      });
  };
  return (
    <>
    <div className="contact_page_sr">
      <div className="container mt-5">
        <div className="left-content">
          <h1 className="mb-3">Connect with Our Team!</h1>
          <p>Whether you have questions, feedback, or just want to say hi, we're all ears! Your thoughts and ideas matter to us, so don't hesitate to reach out. We can't wait to hear from you!</p>
        </div>
        <div className="right-content">
          <form onSubmit={onSubmit}>
            <div className="mb-3">
              <label className="form-label" htmlFor="name">
                Your Name
              </label>
              <input className="form-control" type="text" id="name" required />
            </div>
            <div className="mb-3">
              <label className="form-label" htmlFor="email">
              Your Email
              </label>
              <input className="form-control" type="email" id="email" required />
            </div>
            <div className="mb-3">
              <label className="form-label" htmlFor="message">
              Your Message
              </label>
              <textarea className="form-control" id="message" required />
            </div>
            <button className="btn btn-danger" type="submit">
              {formStatus}
            </button>
          </form>
        </div>
        
      </div>
    </div>
    <Footer />
    </>
  )
}
export default ContactUs