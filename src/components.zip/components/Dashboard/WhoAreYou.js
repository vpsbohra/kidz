import { Link, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';

export default function Dashboard() {
    const location = useLocation();
    const [selectedItem, setSelectedItem] = useState(null);

    useEffect(() => {
        const storedUser = sessionStorage.getItem('user');
        if (storedUser) {
            const user = JSON.parse(storedUser);
            if (user.spouse) {
                setSelectedItem(user.spouse);
            }
        }
    }, []);

    const handleClick = (itemName) => {
        const storedUser = sessionStorage.getItem('user');
        if (storedUser) {
            const user = JSON.parse(storedUser);
            const updatedUser = { ...user, spouse: itemName };
            sessionStorage.setItem('user', JSON.stringify(updatedUser));
            setSelectedItem(itemName);
        }
    };

    return (
        <>
        <div className="who-are-you_inner">
            <div className="container">
                <div className="who-are-you_header">
                    <h1>Who are you?</h1>
                </div>
                <div className="row">
                    <div className={`item-who-are-you profile_type_one col-md-4 ${selectedItem === 'Pierre' ? 'selected' : ''}`} onClick={() => handleClick('Pierre')}>
                        <Link to="/parent-dashboard" name="Pierre">
                            <span className='profile_type_letter'>P</span> Pierre
                        </Link>
                    </div>
                    <div className={`item-who-are-you profile_type_two col-md-4 ${selectedItem === 'Mom' ? 'selected' : ''}`} onClick={() => handleClick('Mom')}>
                        <Link to="/parent-dashboard" name="mom">
                            <span className='profile_type_letter'>M</span> Mom
                        </Link>
                    </div>
                    <div className={`item-who-are-you profile_type_three col-md-4 ${selectedItem === 'Auntie' ? 'selected' : ''}`} onClick={() => handleClick('Auntie')}>
                        <Link to="/parent-dashboard" name="auntie">
                            <span className='profile_type_letter'>A</span> Auntie
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    </>
    );
}
