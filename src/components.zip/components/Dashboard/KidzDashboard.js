import React from 'react';
import KidsNav from '../../navbar/kidzNav';
import KidzBottomNav from './KidzBottomNav';
import KidzSlider from './KidzSlider';
import Gaming1 from '../../images/Games.png';
import Gaming2 from '../../images/Coloring_Pages.png';
import Gaming3 from '../../images/Crossword_Puzzles.png';
import Gaming4 from '../../images/Gallery.png';
import ChildChat from '../chat/ChildChat';

export default function KidzDashboard() {

  return (
    <>
      <div className="kidzdashboard">
        <div className="container-fluid display-table">
          <KidsNav />
          <div className="main-content">
          <div className="page_ttl">
             <h1>Story of the Day</h1>
            </div>
            <KidzSlider />

            <div className="Main_Gaming_Sec">
              <div className="gaming-section games_item">
                <img src={Gaming1} />
                <h3 className='games_ttl'>Games</h3>
              </div>
              <div className="gaming-section colouring_item">
                 <img src={Gaming2} />
                 <h3 className='colouring_ttl'>Coloring</h3>
              </div>
              <div className="gaming-section puzzle_item">
                <img src={Gaming3} />
                <h3 className='puzzle_ttl'> Crossword <br/> Puzzles</h3>
              </div>
              <div className="gaming-section gallery_item">
                 <img src={Gaming4} />
                <h3 className='gallery_ttl'>Photo Gallery</h3>
              </div>
            </div>
          </div>

          <div className="bottom-nav">
            <KidzBottomNav />
          </div>
        </div>
      </div>
    </>
  );
}
