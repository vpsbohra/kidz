import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import AuthUser from '../../components/AuthUser';
import axios from 'axios';

import MykidsImage from '../../images/my_kids.png';
import Mykids_clrImage from '../../images/my_kids_clr.png';
import BillingImage from '../../images/Billings-icon.png';
import SettingsImage from '../../images/Settings-icon.png';
import SuggestImage from '../../images/Suggest-Features-icon.png';
import SupportImage from '../../images/Support-icon.png';
import Billing_whtImage from '../../images/Billings-icon_white.png';
import Settings_whtImage from '../../images/Settings-icon_white.png';
import Suggest_whtImage from '../../images/Suggest-Features-icon_white.png';
import Support_whtImage from '../../images/Support-icon_white.png';
import LogoutImage from '../../images/Logout_icon.png';
import ParentHeaderSection from './ParentHeaderSection';
import Chat from '../chat/Chat';
import Settings from './Settings';
import BillingAndSubscription from './BillingAndSubscription';

const ParentDashboard = () => {
  const { http } = AuthUser();
  const [userdetail, setUserdetail] = useState('');
  const [childProfiles, setChildProfiles] = useState([]);
  const { token, logout } = AuthUser();
  const { user } = AuthUser();
  const [userId, setUserId]  = useState(user.id);
  const [selectedChildId, setSelectedChildId] = useState(null);
  const [profileImage, setProfileImage] = useState(null);

  const [activeComponent, setActiveComponent] = useState('parentHeaderSection');
  const handleLiClick = (componentName) => {
    setActiveComponent(componentName);
  };

  const logoutUser = () => {
    if (token !== undefined) {
      logout();
    } 
  };
  useEffect(() => {
    fetchUserDetail();
    fetchProfileImage();
  }, []);

  const fetchUserDetail = () => {
    setUserdetail(user);
    setUserId(user.id);
    http.get(`/child-profiles?user_id=${userId}`).then((res) => {
      setChildProfiles(res.data); 
    });
  };
  
  function renderElement() {
    if (userdetail) {
      return <p>{userdetail.name.split(' ')[0]}</p>;
    } else {
      return <p>Loading.....</p>;
    }
  }
  
  const handleChildClick = (childId, userId) => {
    setSelectedChildId(childId, userId);
  };

  const fetchProfileImage = async () => {
    try {
        const response = await axios.get(`http://195.110.34.253/api/get-profile-image/${user.id}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        },
        responseType: 'blob',
        });
    
        const imageUrl = URL.createObjectURL(response.data);
        setProfileImage(imageUrl);
    } catch (error) {
        console.error('Error fetching profile image:', error);
    }
    };
  return (
    <>
      <div className="account_created-dash">
        <div className="container-fluid display-table">
          <div className="row display-table-row">
            <div className="col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">
              <div className="logo">
             <Link>{profileImage && (
                <div className="profile_image">
                  <img src={profileImage} alt="Profile" />
                </div>
              )}</Link> 
                <p>{renderElement()}</p>
              </div>
              <div className="navi">
                <ul className="navi-ul">
                   <li
          className={`item ${activeComponent === 'parentHeaderSection' ? 'active' : ''}`}
          onClick={() => handleLiClick('parentHeaderSection')}
       >
                    <div className="child-list">
                      <h2><img className='Left_img_clr' src={Mykids_clrImage} alt="protected" /><img className='Left_img_active' src={MykidsImage} alt="protected" />My Kids</h2>
                      {childProfiles.length > 0 ? (
                        
                        <ul>
                          {childProfiles.map((childProfile) => (
                            <li key={childProfile.id} onClick={() => handleChildClick(childProfile.id)}>
                              {childProfile.child_name}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p>No child profiles found.</p>
                      )}
                    </div>
                  </li>
                   <li
          className={`item ${activeComponent === 'BillingAndSubscription' ? 'active' : ''}`}
          onClick={() => handleLiClick('BillingAndSubscription')}
        >
                    <Link href="#">
                      <span className="hidden-xs hidden-sm"><img className='Left_img_clr' src={BillingImage} alt="protected" /><img className='Left_img_active' src={Billing_whtImage} alt="protected" /> Billing and Subscription</span>
                    </Link>
                  </li>
                  <li
          className={`item ${activeComponent === 'Settings' ? 'active' : ''}`}
          onClick={() => handleLiClick('Settings')}
        >
                    <Link href="#">
                      <span className="hidden-xs hidden-sm"><img className='Left_img_clr' src={SettingsImage} alt="protected" /><img className='Left_img_active' src={Settings_whtImage} alt="protected" /> Settings</span>
                    </Link>
                  </li>
                  <li>
                    <Link href="#">
                      <span className="hidden-xs hidden-sm"><img className='Left_img_clr' src={SuggestImage} alt="protected" /><img className='Left_img_active' src={Suggest_whtImage} alt="protected" /> Suggest Features</span>
                    </Link>
                  </li>
                  <li>
                    <Link href="#">
                      <span className="hidden-xs hidden-sm"><img className='Left_img_clr' src={SupportImage} alt="protected" /><img className='Left_img_active' src={Support_whtImage} alt="protected" /> Support</span>
                    </Link>
                  </li>
                  <li>
                    <Link href="#">
                      <span onClick={logoutUser} className="hidden-xs hidden-sm"><img src={LogoutImage} alt="protected" /> Logout</span>
                    </Link>
                  </li>
                </ul>
                <div className="switch-dashboard">
                  <Link className="active" to="/parent-dashboard" >Parents</Link>
                  <Link className="" to="/kids-listing" >Kids</Link>
                </div>
              </div>
            </div>
            {activeComponent === 'parentHeaderSection' ? (
              <ParentHeaderSection childId={selectedChildId} userId={userId} />
            ) : activeComponent === 'Settings' ? (
              <Settings />
            ) : activeComponent === 'BillingAndSubscription' ? (
              <BillingAndSubscription />
            ) : null}
          </div>
        </div>
      </div>
    </>
  );
};

export default ParentDashboard;
