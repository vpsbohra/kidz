import Chat from '../chat/Chat';
import React, { useEffect, useState } from 'react';
import AuthUser from '../../components/AuthUser';

export default function ParentHeaderSection(props) {
    const [childProfiles, setChildProfiles] = useState([]);
    const { http } = AuthUser();
    const [userdetail, setUserdetail] = useState('');
    const { token, logout } = AuthUser();
    const { user } = AuthUser();
    const [userId, setUserId]  = useState(user.id);

    useEffect(() => {
        fetchUserDetail();
        // fetchChildProfiles();
      }, []);
    const fetchUserDetail = () => {
        setUserdetail(user);
        setUserId(user.id);
        http.get(`/child-profiles?user_id=${userId}`).then((res) => {
          setChildProfiles(res.data); 
        });
      };
    const chatComponents = childProfiles.map((childProfile) => (
        <Chat dataId={childProfile.id} key={childProfile.id} />
      ));
    return (
        <>
                 <div className='right_sidebar_parent'>
                    <div className='top_currently_parent'>
                        <div className='main_heading'>
                            <h3> Currently Reading </h3>
                        </div>
                        <div className='inner-container'>
                            <div className='inner-container-left'>
                                <svg width="121" height="121" viewBox="0 0 121 121" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect width="121" height="121" rx="8" fill="#D9D9D9" />
                                    <path d="M68 66.3333V54.6667C68 53.75 67.25 53 66.3333 53H54.6667C53.75 53 53 53.75 53 54.6667V66.3333C53 67.25 53.75 68 54.6667 68H66.3333C67.25 68 68 67.25 68 66.3333ZM57.5833 61.75L59.6667 64.2583L62.5833 60.5L66.3333 65.5H54.6667L57.5833 61.75Z" fill="#F3F3F3" />
                                </svg>
                            </div>
                            <div className='inner-container-right'>
                                <h4>Lorem ipsum dolor sit amet consectetur</h4>
                                <p>Lorem ipsum dolor sit amet consectetur. Commodo ultricies volutpat ullamcorper morbi morbi nam tortor sed.</p>
                            </div>
                        </div>
                    </div>
                <div className='top_interactions_parent'>
                    <div className='top_interactions_parent_inner'>
                        <div className='main_heading'>
                            <h3>Interactions</h3>
                        </div>

                        <div className='interactions_parent_rightbtn'>
                            <button>Audios <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15.5 5L5.5 15M5.5 5L15.5 15" stroke="#00897B" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                            </svg></button>
                            <button>Vocabulary <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15.5 5L5.5 15M5.5 5L15.5 15" stroke="#00897B" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                            </svg></button>
                            <button><svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5.5 10H15.5M3 5H18M8 15H13" stroke="#00897B" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                            </svg> More filters</button>
                        </div>
                    </div>
                </div>
                {props.childId && <Chat key={props.childId} dataId={props.childId} userId={props.userId}/>}
            </div>
        </>
    );
}