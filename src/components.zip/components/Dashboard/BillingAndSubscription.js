import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import AuthUser from '../AuthUser';

import CirclePlu01Img from '../../images/Circle_Plus01.png';
const BillingAndSubscription = () => {
  const navigate = useNavigate();
  const [currentPlan, setCurrentPlan] = useState('');
  const [currenBilling, setCurrentBilling] = useState('');
  const [userId, setUserId] = useState('');
  const [member, isMember] = useState(false);
  const { token } = AuthUser();
  const [members, setMembers] = useState([]);
  const [errors, setErrors] = useState({});
  const [payments, setPayments] = useState([]);
  const [addMemberSuccess, setAddMemberSuccess] = useState(false);
  const [memberName, setMemberName] = useState('');
  function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const formattedDate = new Date(dateString).toLocaleDateString('en-US', options);
  
    const day = new Date(dateString).getDate();
    const daySuffix = getDaySuffix(day);
  
    return formattedDate.replace(/\d{1,2}/, `${day}${daySuffix}`);
  }
  
  function getDaySuffix(day) {
    if (day >= 11 && day <= 13) {
      return 'th';
    }
    const lastDigit = day % 10;
    switch (lastDigit) {
      case 1:
        return 'st';
      case 2:
        return 'nd';
      case 3:
        return 'rd';
      default:
        return 'th';
    }
  }
  
 function close(){
  setAddMemberSuccess(false);
  isMember(false);
 }

  useEffect(() => {
    const userInformation = sessionStorage.getItem('user');
    const user = JSON.parse(userInformation);
    const { plan } = user;
    const { billing } = user;
    const { id } = user;

    setCurrentPlan(plan);
    setCurrentBilling(billing);
    setUserId(id);
  }, []);
  useEffect(() => {
    const fetchMembers = async () => {
      try {
        const response = await axios.get(`http://195.110.34.253/api/members/${userId}`);
        const membersData = response.data;
        setMembers(membersData);
      } catch (error) {
        console.error('Error fetching members:', error);
      }
    };
    fetchMembers();
  }, [userId]); 
  useEffect(() => {
    const fetchPaymentHistory = async () => {
      try {
        const response = await axios.get(`http://195.110.34.253/api/payment-details/${userId}`);
        const paymentsData = response.data;
        setPayments(paymentsData);
      } catch (error) {
        console.error('Error fetching payment history:', error);
      }
    };
  
    fetchPaymentHistory();
  }, [userId]); 
  const myComponentStyle = {
    width: '72%',
  };
    const handleAddMember = () => {
      const headers = {   
        "Content-type" : "application/json",
        "Authorization" : `Bearer ${token}` 
    };
      const firstName = document.getElementsByName('fname')[0].value;
      const lastName = document.getElementsByName('lname')[0].value;
      const email = document.getElementsByName('email')[0].value;
      const phone = document.getElementsByName('phone')[0].value;
      setMemberName(firstName);
      const memberData = {
        first_name: firstName,
        last_name: lastName,
        email: email,
        phone: phone,
        user_id: userId,
      };
  
      axios.post('http://195.110.34.253/api/add-member', memberData, {headers})
        .then(response => {
          console.log('Member added successfully:', response.data);
          // isMember(false);
          setErrors({});
          setAddMemberSuccess(true);
        })
        .catch(error => {
          if (error.response && error.response.data && error.response.data.errors) {
            setErrors(error.response.data.errors);
          } else {
            console.error('Error adding member:', error);
          }
        });
    };

 
    
  return (
    <>
      <div className="main-container" style={myComponentStyle}>
      {member && (
            <div className="password-update">
           <button className='closed_popup_password' onClick={close}>x</button>
          <div className="add-member">
           <h2>Add a Member</h2>
           {addMemberSuccess ? ( 
              <div className="success">
                {memberName} has been successfully added!
              </div>
            ) : (
              <div className="add-member">
                <h2>Add a Member</h2>
                <div className="form-group">
                  <label>First Name*</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Enter Name"
                    name="fname"
                  />
                  {errors && errors.first_name && (
                    <p className="error-message">{errors.first_name}</p>
                  )}
                </div>

                <div className="form-group">
                  <label>Last Name</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Enter Name"
                    name="lname"
                  />
                  {errors && errors.last_name && (
                    <p className="error-message">{errors.last_name}</p>
                  )}
                </div>
                <div className="form-group">
                  <label>Email*</label>
                  <input
                    type="email"
                    className="form-control"
                    placeholder="Enter email address"
                    name="email"
                  />
                  {errors && errors.email && (
                    <p className="error-message">{errors.email}</p>
                  )}
                </div>
                <div className="form-group">
                  <label>Phone Number</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Enter phone number"
                    name="phone"
                  />
                  {errors && errors.phone && (
                    <p className="error-message">{errors.phone}</p>
                  )}
                </div>
              </div>
            )}
           <div className="form-group payment_btn_lastoption">
                <button onClick={handleAddMember} className='add_paymentplan'>Add to your payment plan</button>
                <button className='send_invitation'>Send an invitation</button>
                <p>*The additional fee of $3.5/month will be covered by the member themselves</p>
            </div>
          </div>
           
            </div>
          )}
        <div className="Billing_Subscriptions_main">
          <h1>Billing and Subscriptions</h1>
          <div className="billing-content">
            <div className="current-pan">
              <h2>Current Plan:</h2>
              <div className="billing_dd-pan">
            
              {currentPlan === 'free' ? (
                 <div className='currentPlan_sr'>
                <p>{currentPlan}</p> 
                <p>
                  <Link to='/subscription'>Explore Plans</Link>
                </p>

                </div>
                
              ) : currentPlan === 'classic' ? (
                <>
                 <div className='currentPlan_sr'>
                <p>{currentPlan}</p> 
                <p>
                  <Link to='/subscription'>Upgrade Plan</Link>
                </p>
                </div>
                <p className='monthly_prgph'>Monthly (Renews on August 17th, 2023)</p>
              
                </>
                
              ) : (
                <>
                  <div className='currentPlan_sr'>
                  <p>{currentPlan}</p> 
                <p>
                  <Link to='/subscription'>Change Plan</Link>
                </p>
                </div>
                <p className='monthly_prgph'>Monthly (Renews on August 17th, 2023)</p>
                <span>Switch to a Yearly plan and save up to 50%</span>
                </>
                
              )
              }
              </div>
            </div>
            <div className="extended-family">
              <h2>Extended Family</h2>
              {currentPlan === 'free' ? (
                <p>
                 Only available on our premium plans.
                </p>
              ) : (
                <>
                <div className="manage_member_sr">
                <div className="members-list">
                {members.map((member) => (
                  <div className="member-input" key={member.id}>
                    <p>{member.first_name} {member.last_name}</p> <button>Manage Member</button>
                  </div>
                ))}
                </div>
            </div>
               <div className="add-member">
               {isMember && (
                          <button className='' onClick={() => isMember(true)}><img src={CirclePlu01Img} alt="protected" /> Add a member</button>
                      )}
                </div>
                </>
                
              )}
            </div>
            <div className="payment-method">
              <h2>Payment Method</h2>
              {currentPlan === 'free' ? (
                <p>
                Select a Plan and Add a Payment Method
                </p>
              ) : (
                <>
              
                {payments.map((payment) => (
                  <tr key={payment.id}>
                      <div className="payment-method"><p>Credit Card ending in {payment.cardLast4}</p> <button>Edit</button></div>
                  </tr>
                ))}
                </>
                
              )}
            </div>
            <div className="billing-history">
              <h2>Billing History</h2>
              {currentPlan === 'free' ? (
                <p>
               Once you select a subscription plan, billing history will appear here.
                </p>
              ) : (
                <>
             <table class="table">
              <thead>
                <tr>
                  <th scope="col">Date</th>
                  <th scope="col">Amount</th>
                  <th scope="col">Details</th>
                </tr>
              </thead>
              <tbody>
              {payments.map((payment) => (
                <tr key={payment.id}>
                  <td>{formatDate(payment.created_at)}</td>
                  <td>${ parseFloat(payment.price.replace(/[^0-9.]/g, ''))}.00 USD</td>
                  <td>{currentPlan}, {currenBilling}</td>
                </tr>
              ))}
              </tbody>
            </table>
              
                </>
                
              )}
            </div>
            {/* Display other billing and subscription information here */}
          </div>
        </div>
      </div>
    </>
  );
};

export default BillingAndSubscription;
